<?php

define('DB_SERVER', 'localhost');
define('DB_NAME', 'gamedb');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'skelet123');
define('DB_PREFIX', '');

define('NUMBER_OF_ROWS_IN_PAGE', 10);

define('DEFAULT_CONTROLLER', 'index');

