# P175B602 - Lab Work

Data entry system to be used as an example solution for lab work assignments in Databases module.

## Progress:
For now, added only views for everything, console and game has an entry class in it(game_form.php and console_form.php)
Only made everything required for a 5, but will improve it later, because i like working with php

