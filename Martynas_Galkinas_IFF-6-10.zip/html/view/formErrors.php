<?php if(!empty($formErrors)) { ?>
<div class="errorBox">
  Neįvesti arba neteisingai įvesti šie laukai:
	<?php echo $formErrors; ?>
</div>
<?php }

